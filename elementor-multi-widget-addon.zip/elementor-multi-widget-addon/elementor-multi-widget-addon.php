<?php
/**
 * Plugin Name: Elementor Multi Widget Addon
 * Description: A custom Elementor plugin that contains multiple widgets.
 * Version: 1.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly

// Load the widgets
function register_multi_elementor_widgets($widgets_manager) {
    require_once(__DIR__ . '/widgets/custom-widget-one.php');
    require_once(__DIR__ . '/widgets/custom-widget-two.php');
    // Add more widget files as needed

    $widgets_manager->register(new \Elementor_Custom_Widget_One());
    $widgets_manager->register(new \Elementor_Custom_Widget_Two());
}

add_action('elementor/widgets/register', 'register_multi_elementor_widgets');
