<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Elementor_Custom_Widget_One extends \Elementor\Widget_Base {

    public function get_name() {
        return 'custom_widget_one';
    }

    public function get_title() {
        return __('Mohosin', 'plugin-name');
    }

    public function get_icon() {
        return 'eicon-text';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'plugin-name'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // Add controls here
        $this->add_control(
            'text',
            [
                'label' => __('Text', 'plugin-name'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Default Text', 'plugin-name'),
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        echo '<div class="custom-widget-one">';
        echo '<h3>' . esc_html($settings['text']) . '</h3>';
        echo '</div>';
    }
}
