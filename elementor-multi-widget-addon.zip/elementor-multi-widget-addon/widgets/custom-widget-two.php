<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Elementor_Custom_Widget_Two extends \Elementor\Widget_Base {

    public function get_name() {
        return 'custom_widget_two';
    }

    public function get_title() {
        return __('Custom Widget Two', 'plugin-name');
    }

    public function get_icon() {
        return 'eicon-button';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'plugin-name'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // Add controls here
        $this->add_control(
            'button_text',
            [
                'label' => __('Button Text', 'plugin-name'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Click Me', 'plugin-name'),
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        echo '<div class="custom-widget-two">';
        echo '<button>' . esc_html($settings['button_text']) . '</button>';
        echo '</div>';
    }
}
