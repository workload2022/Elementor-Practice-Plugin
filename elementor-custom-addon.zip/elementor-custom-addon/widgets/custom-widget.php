<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Elementor_Custom_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'custom_widget';
    }

    public function get_title() {
        return __('Custom Widget', 'plugin-name');
    }

    public function get_icon() {
        return 'eicon-site-title';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'plugin-name'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'name',
            [
                'label' => __('Name', 'plugin-name'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('John Doe', 'plugin-name'),
                'placeholder' => __('Enter your name', 'plugin-name'),
            ]
        );

        $this->add_control(
            'address',
            [
                'label' => __('Address', 'plugin-name'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('123 Main St, City, Country', 'plugin-name'),
                'placeholder' => __('Enter your address', 'plugin-name'),
            ]
        );

        $this->add_control(
            'google_url',
            [
                'label' => __('Google URL', 'plugin-name'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://www.google.com', 'plugin-name'),
                'default' => [
                    'url' => 'https://www.google.com',
                    'is_external' => true,
                    'nofollow' => true,
                ],
            ]
        );

        // Image Field 1
        $this->add_control(
            'image_one',
            [
                'label' => __('Image 1', 'plugin-name'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => '', // Default URL if needed
                ],
            ]
        );

        // Image Field 2
        $this->add_control(
            'image_two',
            [
                'label' => __('Image 2', 'plugin-name'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => '', // Default URL if needed
                ],
            ]
        );

        // Background Image
        $this->add_control(
            'background_image',
            [
                'label' => __('Background Image', 'plugin-name'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => '', // Default URL if needed
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        echo '<div class="custom-widget" style="background-image: url(' . esc_url($settings['background_image']['url']) . ');">';
        echo '<h3>' . esc_html($settings['name']) . '</h3>';
        echo '<p>' . esc_html($settings['address']) . '</p>';
        if (!empty($settings['google_url']['url'])) {
            echo '<a href="' . esc_url($settings['google_url']['url']) . '" target="_blank" rel="nofollow">View on Google</a>';
        }

        // Render Image 1
        if (!empty($settings['image_one']['url'])) {
            echo '<img src="' . esc_url($settings['image_one']['url']) . '" alt="' . esc_attr($settings['name']) . ' Image 1">';
        }

        // Render Image 2
        if (!empty($settings['image_two']['url'])) {
            echo '<img src="' . esc_url($settings['image_two']['url']) . '" alt="' . esc_attr($settings['name']) . ' Image 2">';
        }

        echo '</div>';
    }
}
