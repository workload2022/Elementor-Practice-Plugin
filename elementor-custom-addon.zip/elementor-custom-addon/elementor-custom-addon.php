<?php
/**
 * Plugin Name: Elementor Custom Addon
 * Description: Adds a custom widget with Name, Address, and Google URL fields.
 * Version: 1.0
 * Author: Your Name
 * Tested up to: 3.25.3  // Update this to your current Elementor version
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly

// Load custom widget
function register_custom_elementor_widget($widgets_manager) {
    require_once(__DIR__ . '/widgets/custom-widget.php');
    $widgets_manager->register(new \Elementor_Custom_Widget());
}

add_action('elementor/widgets/register', 'register_custom_elementor_widget');
